"""Small helpers shared by the training scripts."""
from __future__ import annotations

from pathlib import Path

import yaml

HERE = Path(__file__).resolve().parent
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def load_classes(path: Path = HERE / "classes.yaml") -> list[dict]:
    classes = yaml.safe_load(path.read_text(encoding="utf-8"))["classes"]
    names = [c["name"] for c in classes]
    if len(set(names)) != len(names):
        raise SystemExit(f"duplicate class names in {path}")
    return classes


def class_names() -> list[str]:
    return [c["name"] for c in load_classes()]


def write_source(out: Path, items: list[tuple[Path, list[tuple[str, float, float, float, float]]]]) -> None:
    """Writes a "source" folder in the layout build_dataset.py merges:
    images/, labels/ (YOLO txt), classes.txt. Boxes are (class_name, cx, cy, w, h), normalised."""
    import shutil

    names = class_names()
    (out / "images").mkdir(parents=True, exist_ok=True)
    (out / "labels").mkdir(parents=True, exist_ok=True)
    (out / "classes.txt").write_text("\n".join(names) + "\n", encoding="utf-8")
    for image, boxes in items:
        shutil.copy2(image, out / "images" / image.name)
        lines = [f"{names.index(c)} {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}" for c, cx, cy, w, h in boxes]
        (out / "labels" / f"{image.stem}.txt").write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
